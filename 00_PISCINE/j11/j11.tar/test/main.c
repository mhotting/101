/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   main.c                                           .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: mhotting <marvin@le-101.fr>                +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/07/17 18:08:31 by mhotting     #+#   ##    ##    #+#       */
/*   Updated: 2018/07/17 20:43:47 by mhotting    ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include "ft_list.h"
#include <stdio.h>

void	disp_list(t_list *begin)
{
	t_list *current;

	current = begin;
	printf("MY LIST: ");
	while (current != 0)
	{
		if (current->next != 0)
			printf("%d - ", current->x);
		else
			printf("%d\n\n", current->x);
		current = current->next;
	}
}

void	disp_list_elt(t_list *elt)
{
	if (elt != 0)
		printf("+++ %d +++\n", elt->x);
}

int		main(int argc, char **argv)
{
	t_list	*list1;
	t_list	*list2;
	t_list	*list3;

	list1 = 0;
	list2 = 0;
	list3 = 0;
	ft_list_push_back(&list1, 40);
	ft_list_push_back(&list1, 30);
	ft_list_push_back(&list1, 20);
	ft_list_push_back(&list1, 10);
	ft_list_push_back(&list1, 0);
	disp_list(list1);
	ft_list_push_front(&list1, 90);
	ft_list_push_front(&list1, 120);
	disp_list(list1);
	ft_list_push_front(&list2, 99);
	disp_list(list2);
	printf("Size of list1: %d\nSize of list2: %d\nSize of list3: %d\n", ft_list_size(list1), ft_list_size(list2), ft_list_size(list3));
	disp_list_elt(ft_list_last(list1));
	disp_list_elt(ft_list_last(list2));
	disp_list_elt(ft_list_last(list3));
	list3 = ft_list_push_params(argc, argv);
	disp_list(list3);
}
